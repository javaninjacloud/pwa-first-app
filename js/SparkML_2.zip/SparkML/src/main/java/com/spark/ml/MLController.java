package com.spark.ml;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.spark.api.java.function.Function;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.ml.Pipeline;
import org.apache.spark.ml.PipelineModel;
import org.apache.spark.ml.PipelineStage;
import org.apache.spark.ml.classification.DecisionTreeClassificationModel;
import org.apache.spark.ml.classification.DecisionTreeClassifier;
import org.apache.spark.ml.classification.NaiveBayes;
import org.apache.spark.ml.classification.RandomForestClassificationModel;
import org.apache.spark.ml.classification.RandomForestClassifier;
import org.apache.spark.ml.clustering.KMeans;
import org.apache.spark.ml.clustering.KMeansModel;
import org.apache.spark.ml.evaluation.MulticlassClassificationEvaluator;
import org.apache.spark.ml.evaluation.RegressionEvaluator;
import org.apache.spark.ml.feature.HashingTF;
import org.apache.spark.ml.feature.IDF;
import org.apache.spark.ml.feature.IndexToString;
import org.apache.spark.ml.feature.LabeledPoint;
import org.apache.spark.ml.feature.PCA;
import org.apache.spark.ml.feature.PCAModel;
import org.apache.spark.ml.feature.StringIndexer;
import org.apache.spark.ml.feature.StringIndexerModel;
import org.apache.spark.ml.feature.Tokenizer;
import org.apache.spark.ml.linalg.Vector;
import org.apache.spark.ml.linalg.Vectors;
import org.apache.spark.ml.recommendation.ALS;
import org.apache.spark.ml.recommendation.ALSModel;
import org.apache.spark.ml.regression.LinearRegression;
import org.apache.spark.ml.regression.LinearRegressionModel;
import org.apache.spark.ml.regression.LinearRegressionTrainingSummary;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import com.spark.ml.SparkConnection;

import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import org.apache.spark.util.DoubleAccumulator;
import org.apache.spark.util.LongAccumulator;
import org.apache.spark.sql.SparkSession;

import static org.apache.spark.sql.functions.*;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MLController implements Serializable {

    @GetMapping("/myDB")
    public String myDB() {
        SparkSession spSession = SparkConnection.getSession();

        Dataset<Row> rawDf = spSession.read()
                .csv("D:\\dev\\spark-big-data-analytics\\data\\ratings.txt");
        rawDf.show(5);
        rawDf.printSchema();

		/*--------------------------------------------------------------------------
		Cleanse Data - convert data type
		--------------------------------------------------------------------------*/

        //Create the schema for the data to be loaded into Dataset.
        StructType ratingsSchema = DataTypes
                .createStructType(new StructField[] {
                        DataTypes.createStructField("user", DataTypes.IntegerType, false),
                        DataTypes.createStructField("item", DataTypes.IntegerType, false),
                        DataTypes.createStructField("rating", DataTypes.DoubleType, false)
                });

        JavaRDD<Row> rdd1 = rawDf.toJavaRDD();

        //Function to map.
        JavaRDD<Row> rdd2 = rdd1.map( new Function<Row, Row>() {

            @Override
            public Row call(Row iRow) throws Exception {

                Row retRow = RowFactory.create(
                        Integer.valueOf(iRow.getString(0)),
                        Integer.valueOf(iRow.getString(1)),
                        Double.valueOf(iRow.getString(2)) );

                return retRow;
            }

        });

        List liTest =new ArrayList();
        liTest.add(1003);
        liTest.add(9001);
        //liTest.add(1003);

        List<Row> rowsTest = new ArrayList<>();
        //rowsTest.add(RowFactory.create("1003", "9001","0"));
        rowsTest.add(RowFactory.create("555", "471","0"));

        JavaRDD<Row> rddTest = SparkConnection.getContext().parallelize(rowsTest);

        Dataset<Row> ratingsDf = spSession.createDataFrame(rdd2, ratingsSchema);
        System.out.println("Ratings Data: ");
        //ratingsDf.show(5);

		/*--------------------------------------------------------------------------
		Perform Machine Learning
		--------------------------------------------------------------------------*/

        Dataset<Row>[] splits = ratingsDf.randomSplit(new double[]{0.9, 0.1});
        Dataset<Row> training = splits[0];
        Dataset<Row> test = splits[1];
        //Dataset<Row> test1 = new Dataset<Row>();



        JavaRDD<Row> rddTest2 = rddTest.map( new Function<Row, Row>() {

            @Override
            public Row call(Row iRow) throws Exception {

                Row retRow = RowFactory.create(
                        Integer.valueOf(iRow.getString(0)),
                        Integer.valueOf(iRow.getString(1)),
                        Double.valueOf(iRow.getString(2)) );

                return retRow;
            }

        });
        Dataset<Row> test1= spSession.createDataFrame(rddTest2, ratingsSchema);

        ALS als = new ALS()
                .setMaxIter(5)
                .setRegParam(0.01)
                .setUserCol("user")
                .setItemCol("item")
                .setRatingCol("rating");

        ALSModel model = als.fit(training);

        // Evaluate the model by computing the RMSE on the test data
        Dataset<Row> predictions = model.transform(test);
        // Dataset<Row> predictions = model.transform(test1);

        System.out.println("Predictions : ");
        predictions.show();

        // Keep the program running so we can checkout things.
        //ExerciseUtils.hold();



        return "Hello";
    }

}
